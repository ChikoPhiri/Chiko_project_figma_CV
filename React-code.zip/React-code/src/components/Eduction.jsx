import React from 'react';
import Header from './Header';
import EducationSection from './EducationSection';

function Education() {
  return (
    <div>
      <Header />
      <EducationSection />
    </div>
  );
}

export default Education;
