import React from 'react';
import '../components/Header.css';
import { Link } from 'react-router-dom';

function Header() {
  return (
    <header className='header'>
      <ul className='ul-header'>
        <Link to='/'>
          <li id='header-li'>Home</li>
        </Link>
        <Link to='/about'>
          <li id='header-li'  >About</li>
        </Link>
   
        <Link to='/contact'>
          <li id='header-li'>Contact</li>
        </Link>
        <Link to='/skills'>
          <li id='header-li'>Skills</li>
        </Link>
        <Link to='/education'>
          <li id='header-li'>Education</li>
        </Link>
      </ul>
    </header>
  );
}

export default Header;
