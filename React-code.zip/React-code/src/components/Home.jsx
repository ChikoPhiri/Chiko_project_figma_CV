import React from 'react'
import Header from '../components/Header.jsx';
import HomeSection from './HomeSection.jsx';
import {media} from '../components/Data.js'
import Card from "../components/Homecard.jsx";
import '../components/Home.css'

function Home() {
  return (
    <div>
      
      <Header />
      <HomeSection />
     <div className='media-home'>
     <Card {...media[0]}/>
      <Card {...media[1]}/>
      <Card {...media[2]}/>
     </div>
      


    </div>
  );
}

export default Home;
