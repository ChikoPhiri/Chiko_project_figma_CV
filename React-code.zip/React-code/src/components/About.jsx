import React from 'react';
import Header from './Header';
import AboutSection from './AboutSection';

function About() {
  return (
    <div>
      <Header />
      <AboutSection />
    </div>
  );
}

export default About;
