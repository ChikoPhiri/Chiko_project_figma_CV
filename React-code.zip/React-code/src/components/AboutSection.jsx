import React from "react";
import "../components/About.css";
import pic from "../Assest/chiko.jpg";

function AboutSection() {
  return (
    <div className="main-about">
      <section className="about-pic">
        <img src={pic} alt="Profile" className="profile-pic"/>
        <button className="role-button">Software Developer</button>
        <div className="detail">
          <h3>PERSONAL DETAILS</h3>
          <p className="pd">
            ID: 9804100613088
            <br />
            Date of Birth: 10 April 1998
            <br />
            Sex: Female
            <br />
            Nationality: South African
            <br />
            Marital status: Single
            <br />
            Address: Unit 172, Waterford View Estate, Oosterland Avenue,
            Bloubosrand, Johannesburg
          </p>
        </div>
      </section>
      <section className="about">
        <div className="about-content">
          <h3>About</h3>
          <p>
            I am a creative problem-solver with a strong passion for art and
            teamwork. I thrive in collaborative environments where I can
            leverage my skills in C#, React, SQL, JavaScript, CSS, and HTML to
            develop innovative solutions. My approach to problem-solving is both
            analytical and creative, allowing me to tackle challenges
            effectively. I am dedicated to continuous learning and believe in
            the power of technology and art to make a positive impact.
          </p>
          <div className="small">
            <h1>Language</h1>
            <ul>
              <li>English</li>
              <li>South Africa</li>
            </ul>
          </div>
          <div className="grid-skills">
            <aside>
              <div className="skills">
                <h2>SKILLS</h2>
                <ul>
                  <li>Creative thinking and problem-solving</li>
                  <li>
                    Proficient in C#, React, SQL, JavaScript, CSS, and HTML
                  </li>
                  <li>Strong teamwork and collaboration abilities</li>
                  <li>
                    Enthusiastic about leveraging technology and art for
                    meaningful outcomes.
                  </li>
                </ul>
              </div>
            </aside>
            <aside>
              <div className="traits">
                <h2>Professional Traits</h2>
                <ul>
                  <li>
                    Adept at combining technical expertise with creative thinking.
                  </li>
                  <li>Effective communicator and team player.</li>
                  <li>Proactive in learning and adapting to new technologies.</li>
                  <li>
                    Passionate about contributing to projects that drive positive
                    change.
                  </li>
                </ul>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </div>
  );
}

export default AboutSection;
