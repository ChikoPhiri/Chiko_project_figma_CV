import React from 'react';
import '../components/Skills.css';
import Card from './Card';
import { skills } from './Data';

function SkillSection() {
  return (
    <div className='main-skill'>
      <h1>Skills</h1>
      <div className='skills'>
        {skills.map((skill, index) => (
          <Card key={index} {...skill} />
        ))}
      </div>
    </div>
  );
}

export default SkillSection;
