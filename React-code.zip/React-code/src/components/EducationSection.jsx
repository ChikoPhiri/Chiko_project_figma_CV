import React from "react";
import "../components/Education.css";
import CardE from "./CardE";
import { educations, reference } from "./Data";

function EducationSection() {
  return (
    <div className="education-container">
      <div className="education-grid">
        <section className="education-section">
          <h2 className="section-title">Education</h2>
          <div className="education-cards">
            {educations.map((education, index) => (
              <CardE key={index} {...education} />
            ))}
          </div>
        </section>

        <section className="reference-section">
          <h2 className="section-title">References</h2>
          <div className="reference-cards">
            {reference.map((ref, index) => (
              <CardE key={index} {...ref} />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

export default EducationSection;
