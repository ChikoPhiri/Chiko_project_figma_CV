import React from 'react';
import '../components/Homecard.css';

function Homecard(props) {
  return (
    <div className='card'>
      <img className="pic-medias" src={props.image} alt="" />
    </div>
  );
}

export default Homecard;
