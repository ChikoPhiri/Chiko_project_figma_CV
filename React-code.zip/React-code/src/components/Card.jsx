import React from 'react'

function Card(pros) {
  return (
    <div>
      <div className="skills-pic">
        <img src={pros.image} alt="" />
      </div>
      <h1>{pros.title}</h1>
    </div>
  )
}

export default Card
